import os
import random
from PIL import Image, ImageDraw, ImageFont

class RockStack:
    def __init__(self):
        self.canvas_width = 110
        self.canvas_height = 110
        pass

    def stack_number_on_image(self, image, number):
        image = image.convert('RGBA')
        draw = ImageDraw.Draw(image)

        font = ImageFont.load_default()
        text_position = (self.canvas_height/2, self.canvas_width/2)
        text_color = (255, 255, 255, 255)  # White
        draw.text(text_position, str(number), font=font, fill=text_color)
        return image


    def scale_image(self, image, scale_factor):
        new_width = int(image.width * scale_factor)
        new_height = int(image.height * scale_factor)
        return image.resize((new_width, new_height))

    def stack_images(self, N, image_filenames):
        final_image = Image.new('RGBA', (self.canvas_height, self.canvas_width), (0, 0, 0, 0))

        for _ in range(N):
            selected_image_filename = random.choice(image_filenames)
            selected_image = Image.open(selected_image_filename).convert('RGBA')

            rotation_angle = random.randint(0, 360)
            selected_image = selected_image.rotate(rotation_angle)
            scale_factor = float("{0:.2f}".format(random.uniform(0.80, 1.10)))
            selected_image = self.scale_image(selected_image, scale_factor)

            if final_image is None:
                final_image = selected_image
            else:
                final_image.paste(selected_image, (0, 0), selected_image)

        final_image = self.stack_number_on_image(final_image, N)
        final_image.save('stacked_rocks.png')

# Example usage
if __name__ == '__main__':
    rockStack = RockStack()
    image_filenames = ['rock_maroon.png','rock_blue.png','rock_yellow.png','rock_green.png']
    #image_filenames = [f for f in os.listdir('/rocks') if os.path.isfile(os.path.join('/rocks', f))]
    rockStack.stack_images(random.randint(1, 5), image_filenames)